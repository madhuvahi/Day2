package basics;

import java.lang.annotation.Annotation;

//import com.sun.xml.internal.bind.v2.schemagen.xmlschema.Annotation;

class A
{
	@TestAnnotation
	String name;
	A(){
		System.out.println("HI");
	}
	void m1() {
		System.out.println("hello");
	}
}
//class B extends A{
//	@Override
//	void m1() {
//		System.out.println("welcome");
//	}
//}
public class Annotations {
	public static void main(String[] args) {
		
		A a =new A();
		Annotation[] annotation= a.getClass().getAnnotations();
		System.out.println(annotation.length);
				
	}
}
