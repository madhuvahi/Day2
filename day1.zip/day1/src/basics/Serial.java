package basics;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Scanner;

class Box implements Serializable {
	int l, b;

	public Box(int l, int b) {
		super();
		this.l = l;
		this.b = b;
	}

	@Override
	public String toString() {
		return "Box [l=" + l + ", b=" + b + "]";
	}

	public int getL() {
		return l;
	}

	public void setL(int l) {
		this.l = l;
	}

	public int getB() {
		return b;
	}

	public void setB(int b) {
		this.b = b;
	}
}

public class Serial {

	public static void main(String[] args) throws IOException, ClassNotFoundException {
//
//		System.out.println("enter lenght and breadth");
//		Scanner s = new Scanner(System.in);
//		int l = s.nextInt();
//		int b = s.nextInt();
//		Box b1 = new Box(l, b);
//		System.out.println(b1);

//		FileOutputStream fos = new FileOutputStream("C:\\Users\\madhumitha.VS\\Documents\\testfile\\ser");
//		ObjectOutputStream oos = new ObjectOutputStream(fos);
//		
		FileInputStream fis = new FileInputStream("C:\\Users\\madhumitha.VS\\Documents\\testfile\\ser");
		ObjectInputStream ois = new ObjectInputStream(fis);

		Box box = (Box) ois.readObject();
		System.out.println(box);
		// oos.writeObject(b1);

	}
}
