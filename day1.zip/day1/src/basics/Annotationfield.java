package basics;

import java.lang.annotation.Annotation;

class A
{
	
	@TestAnnotation
	int a;
	A(){
		System.out.println("HI");
	}
	void m1() {
		System.out.println("hello");
	}
}
public class Annotationfield {

public static void main(String[] args) {
		
		A a =new A();
		Annotation[] annotation= a.getClass().getAnnotations();
		System.out.println(annotation.length);
		TestAnnotation annotation2 = a.getClass().getAnnotation(TestAnnotation.class);
				System.out.println(annotation2);
				
				
	}
}
