package lambda;

interface IUpper {
	String toUpper(String s);
}

interface Math {
	void add(int a, int b);
}

interface MathR {
	int add(int a, int b);
}

interface NRNP {
	void fun();
}

public class LambdaTest1 {
	public static void main(String[] args) {

		IUpper iupper = (s) -> s.toUpperCase();
		String upper = iupper.toUpper("hello");
		System.out.println(upper);

//		Upper upper = new Upper() {
//		@Override
//		public String toupper(String s) {
//			return "hi";
//		}
//	};
		Math math = (a, b) -> {

			System.out.println(a + b);
		};
		math.add(3, 4);

		MathR mathR = (a, b) -> a + b;// no return then no paranthesis
		System.out.println(mathR.add(2, 1));

		NRNP nrnp = () -> System.out.println("hi");
		nrnp.fun();
	}
}
