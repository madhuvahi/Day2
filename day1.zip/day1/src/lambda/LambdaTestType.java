package lambda;

@FunctionalInterface
interface K {
	void m1();
	// void m3();
}

interface L {
	int getnum();
}

public class LambdaTestType {

	public static void main(String[] args) {

		K k = () -> System.out.println("hi"); // lambda only one method in the interface
		// L l = () -> 9;

		L l1 = new L() {
			@Override
			public int getnum() {
				return 9;
			}
		};
	}
}
