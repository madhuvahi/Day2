package lambda;

interface I {
	void m1();
}

class IM implements I {
	public void m1() {
		System.out.println("in m1 of im");
	}

}

public class LambdaTest {

	public static void main(String[] args) {

		I i = new I() {
			@Override
			public void m1() {
				System.out.println("in 1");
			}

		};
		i.m1();
		IM im = new IM();
		im.m1();
	}
}
