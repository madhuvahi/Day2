package lambda;//consumer-built in interface

import java.util.ArrayList;
import java.util.List;
import java.util.function.BiConsumer;
import java.util.function.BiPredicate;
import java.util.function.Consumer;
import java.util.function.Supplier;

import java.util.function.Function;
import java.util.function.Predicate;

class Box {

	int l, b;

	public Box(int l, int b) {
		super();
		this.l = l;
		this.b = b;
	}

	public int getL() {
		return l;
	}

	public void setL(int l) {
		this.l = l;
	}

	public int getB() {
		return b;
	}

	public void setB(int b) {
		this.b = b;
	}

	@Override
	public String toString() {
		return "Box [l=" + l + ", b=" + b + "]";
	}

}

class Employee {

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getSalary() {
		return salary;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", salary=" + salary + "]";
	}

	public Employee(int id, int salary) {
		super();
		this.id = id;
		this.salary = salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	int id, salary;

}

public class BuiltInDemo {

	public static void main(String[] args) {

		Consumer<String> consumer = (s) -> System.out.println(s);
		consumer.accept("hi");

		Consumer<Integer> consumer1 = (s) -> System.out.println(s * s);
		consumer1.accept(5);

		Box box = new Box(2, 3);
		Consumer<Box> consumer2 = (ox) -> System.out.println(box.getL() * box.getB());
		consumer2.accept(box);

		Supplier<Integer> supplier = () -> 9;
		System.out.println(supplier.get());

		BiConsumer<String, Integer> biconsumer = (a, b) -> System.out.println(a.charAt(b));
		biconsumer.accept("test", 1);

		Function<String, Integer> function = (p) -> p.length();// one as input ant the other output
		System.out.println(function.apply("hello"));

		Employee e = new Employee(100, 12000);
		Employee e1 = new Employee(101, 15000);
		List<Employee> listemp = new ArrayList<Employee>();
		listemp.add(e);
		listemp.add(e1);
		Function<List<Employee>, Integer> function1 = (list) -> {
			int salary = 0;
			for (int i = 0; i < listemp.size(); i++) {
				salary = salary + listemp.get(i).getSalary();
			}
			return salary;
		};
		System.out.println(function1.apply(listemp));

		Predicate<String> predicate = (s) -> {

			if (s.length() > 5)
				return true;
			else
				return false;

		};
		System.out.println(predicate.test("madhumitha"));

		BiPredicate<Integer, Integer> bipredicate = (a, b) -> {// both are inputs
			if (a.equals(b))
				return true;
			else
				return false;
		};

		System.out.println(bipredicate.test(1, 5));
	}
}
