package stream;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

class Employee {

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getSalary() {
		return salary;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", salary=" + salary + "]";
	}

	public Employee(int id, int salary) {
		super();
		this.id = id;
		this.salary = salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	int id, salary;

}

public class StreamDemo {
	public static void main(String[] args) {

		Employee emp1 = new Employee(100, 12000);
		Employee emp2 = new Employee(101, 15000);
		List<Employee> listemp = new ArrayList<Employee>();
		listemp.add(emp1);
		listemp.add(emp2);

//		Stream<Employee> stream=listemp.stream();
//		listemp.stream().filter ((e) -> { 
//			if(e.getId() > 100 )
//				return true;
//			return false;
//			
//			
//		}).forEach(System.out::print);

		List<Integer> li = Arrays.asList(2, 3, 4, 5, 6, 7, 8, 9);
		li.stream().filter((p) -> p > 5).map((s) -> (s + 10)).forEach(System.out::print);

		listemp.stream().filter((e) -> e.getId() > 100).map((e1) -> {
			e1.setSalary(e1.getSalary() + 1000);
			return e1;
		}).forEach(System.out::print);

	}

}
